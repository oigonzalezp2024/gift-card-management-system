<?php

class DenunciaRepository{

    private $conn;

    public function __construct(mysqli $conn)
    {
        $this->conn = $conn;
    }

    function getDenuncias()
    {
        $rows = [];
        $sql = 'SELECT * FROM denuncia_tarjeta';
        $result = mysqli_query($this->conn, $sql);
        while ($row = mysqli_fetch_assoc($result))
        {
            $rows[] = $row;
        }
        return $rows;    
    }


    function getDenunciaByTarjetaCodigo(string $codigo)
    {
        $rows = [];
        $sql = "SELECT * FROM denuncia_tarjeta WHERE tarjeta_codigo={$codigo}";
        $result = mysqli_query($this->conn, $sql);
        while ($row = mysqli_fetch_assoc($result))
        {
            $rows[] = $row;
        }
        return $rows;    
    }

}
