<?php

class TarjetaRepository
{

    private $conn;

    public function __construct(mysqli $conn)
    {
        $this->conn = $conn;
    }

    function getTarjetaByEstrategiaId($estrategia)
    {
        $rows = [];
        $sql = "SELECT
            tar.*,
            CASE
            WHEN de.tarjeta_codigo IS NOT NULL THEN 'SI'
            ELSE NULL
            END AS denuncia
            FROM
            `tarjetas` tar
            LEFT JOIN
            denuncia_tarjeta de ON de.tarjeta_codigo = tar.codigo
            WHERE estrategia_id={$estrategia}
        ";
        $result = mysqli_query($this->conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
        return $rows;
    }

    function getTarjetasDenunciadas($estrategia)
    {
        $rows = [];
        $sql = "SELECT
            tar.*,
            CASE
            WHEN de.tarjeta_codigo IS NOT NULL THEN 'SI'
            ELSE NULL
            END AS denuncia
            FROM
            `tarjetas` tar
            LEFT JOIN
            denuncia_tarjeta de ON de.tarjeta_codigo = tar.codigo
            WHERE estrategia_id={$estrategia}
        ";
        $result = mysqli_query($this->conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
            if($row['denuncia'] == 'SI'){
                $rows[] = $row;
            }
        }
        return $rows;
    }

    function getTarjetasHabilitadas($estrategia)
    {
        $rows = [];
        $sql = "SELECT
            tar.*,
            CASE
            WHEN de.tarjeta_codigo IS NOT NULL THEN 'SI'
            ELSE NULL
            END AS denuncia
            FROM
            `tarjetas` tar
            LEFT JOIN
            denuncia_tarjeta de ON de.tarjeta_codigo = tar.codigo
            WHERE estrategia_id={$estrategia}
        ";
        $result = mysqli_query($this->conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
            if($row['denuncia'] !== 'SI'){
                $rows[] = $row;
            }
        }
        return $rows;
    }
}
