<?php

class EstrategiaRepository
{
    private $conn;

    public function __construct(mysqli $conn)
    {
        $this->conn = $conn;
    }

    function getEstrategiaByAliadoId($aliado)
    {
        $rows = [];
        $sql = "SELECT
            est.*,
            CASE
                WHEN COUNT(de.tarjeta_codigo) > 0 THEN 'SI'
                ELSE 'NO'
            END AS denuncia
            FROM
            estrategia AS est
            LEFT JOIN
            tarjetas AS tar ON tar.estrategia_id = est.id_estrategia
            LEFT JOIN
            denuncia_tarjeta AS de ON de.tarjeta_codigo = tar.codigo
            GROUP BY
            est.id_estrategia
            HAVING
            est.aliado_id = {$aliado}";
        $result = mysqli_query($this->conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
        return $rows;
    }

    function getEstrategiasSinNovedadByAliadoId($aliado)
    {
        $rows = [];
        $sql = "SELECT
            est.*,
            CASE
                WHEN COUNT(de.tarjeta_codigo) > 0 THEN 'SI'
                ELSE 'NO'
            END AS denuncia
            FROM
            estrategia AS est
            LEFT JOIN
            tarjetas AS tar ON tar.estrategia_id = est.id_estrategia
            LEFT JOIN
            denuncia_tarjeta AS de ON de.tarjeta_codigo = tar.codigo
            GROUP BY
            est.id_estrategia
            HAVING
            est.aliado_id = {$aliado}";
        $result = mysqli_query($this->conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
            if($row['denuncia'] == 'NO'){
                $rows[] = $row;
            }
        }
        return $rows;
    }

    function getEstrategiaConDenunciasByAliadoId($aliado)
    {
        $rows = [];
        $sql = "SELECT
            est.*,
            CASE
                WHEN COUNT(de.tarjeta_codigo) > 0 THEN 'SI'
                ELSE 'NO'
            END AS denuncia
            FROM
            estrategia AS est
            LEFT JOIN
            tarjetas AS tar ON tar.estrategia_id = est.id_estrategia
            LEFT JOIN
            denuncia_tarjeta AS de ON de.tarjeta_codigo = tar.codigo
            GROUP BY
            est.id_estrategia
            HAVING
            est.aliado_id = {$aliado}";
        $result = mysqli_query($this->conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
            if($row['denuncia'] == 'SI'){
                $rows[] = $row;
            }
        }
        return $rows;
    }
}
